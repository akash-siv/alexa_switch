# Python Examples

[![Downloads](https://pepy.tech/badge/pysinric)](https://pepy.tech/project/pysinric) [![Downloads](https://pepy.tech/badge/pysinric/week)](https://pepy.tech/project/pysinric/week) [![](https://img.shields.io/pypi/format/pysinric.svg)]() [![](https://img.shields.io/badge/author-Dhanush-brightgreen.svg)](https://github.com/dazzHere)
### Install sinric python package
    pip install pysinric --user

### Pysinric
   [pysinric](https://pypi.org/project/pysinric/)
   
### Upgrade Pysinric to lastest version
    python -m pip install pysinric --upgrade